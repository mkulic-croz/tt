Port dafiniran u values.yaml i korišten u ostalim tameplatima je 80 kao neka common praksa, 
ali možemo iskoristiti naredbu:
```kubecrl port-forward svc/frontend 8090:80```
koja forwarda likalni port koji expose-a port 80 frontend servisa na port 8090 localhosta. 
Nakon toga možemo frontendu pristupiti na localhost:8090. 