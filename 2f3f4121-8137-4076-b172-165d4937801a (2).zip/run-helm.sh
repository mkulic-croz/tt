minikube -p minikube docker-env
eval $(minikube docker-env)

minikube start

cd client
./build.sh

cd ../server
./build.sh

cd ../k8s
helm install frontend ./frontend
helm install backend ./backend

minikube tunnel

