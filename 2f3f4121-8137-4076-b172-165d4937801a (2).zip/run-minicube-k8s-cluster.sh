minikube -p minikube docker-env
eval $(minikube docker-env)

minikube start

cd client
./build.sh

cd ../server
./build.sh

cd ../k8s
kubectl apply -f client-deployment.yaml
kubectl apply -f server-deployment.yaml

minikube tunnel

