docker build . -t app/server

