docker run --network app --rm --name server -t app/server

