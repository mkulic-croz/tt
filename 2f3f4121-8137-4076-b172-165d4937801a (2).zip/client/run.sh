docker run -p 8090:8090 --rm --network app --name client -t app/client

