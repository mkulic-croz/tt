docker build . -t app/client

