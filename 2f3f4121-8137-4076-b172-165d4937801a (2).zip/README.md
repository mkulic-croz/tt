U direktorijima client i server se nalaze datoteke aplikacije sa svojim Dockerfileovima.  

Skripte `client/build.sh` i `server/build.sh` buildaju Docker imagee.
Skripte `client/run.sh` i `server/run.sh` pokreću Docker containere iz buildanih imagea.
Skripta `create-docker-network.sh` stvara Docker network za komunikaciju.  

U direktoriju k8s se nalaze yaml kubernetes fileovi za konviguraciju Deploymenta i Servicea od klijenta i servera.  

Skripta `run-minicube-k8s-cluster.sh` sve što je potrebno da pokrene aplikaciju untar k8s clustera pomoću Minicubea.

U direktorijima frontend i backend se nalaze konfiguracijske datoteke za Helm.  

Skripta `run-helm.sh` što i druga skripta, ali ne koristi raw k8s fileove nego Helm (pomoću kojeg su i konfigurirana ograničenja za resurse i liveness probe).  
